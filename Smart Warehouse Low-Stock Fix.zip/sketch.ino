#include <WiFi.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// ===============================
// KONFIGURASI WIFI WOKWI
// ===============================
const char* ssid     = "Wokwi-GUEST";
const char* password = "";

// ===============================
// KONFIGURASI MQTT
// ===============================
const char* mqtt_server = "broker.hivemq.com";
const int   mqtt_port   = 1883;

const char* mqtt_topic         = "scm/warehouse/rak-1/kelompok1";
const char* mqtt_control_topic = "scm/warehouse/rak-1/kelompok1/control";

// ===============================
// KONFIGURASI OLED
// ===============================
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET   -1
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// ===============================
// MQTT CLIENT
// ===============================
WiFiClient   espClient;
PubSubClient client(espClient);

// ===============================
// PIN SENSOR, LED, & BUZZER
// ===============================
const int trigPin   = 5;
const int echoPin   = 18;
const int ledPin    = 2;
const int buzzerPin = 4;

// ===============================
// VARIABEL
// ===============================
long duration;
int  distance;
bool restockMode = false;

unsigned long lastPublish = 0;
const unsigned long PUBLISH_INTERVAL = 1000;

// ===============================
// BUZZER STATE MACHINE (Beep Intermiten)
// ===============================
enum BuzzerState { BUZZER_IDLE, BUZZER_BEEP, BUZZER_PAUSE };
BuzzerState buzzerState = BUZZER_IDLE;
unsigned long buzzerTimer = 0;
const unsigned long BEEP_DURATION  = 500;    // Nyala 500 ms
const unsigned long PAUSE_DURATION = 2500;   // Diam 2500 ms
const int BUZZER_FREQ = 1500;                // Frekuensi 1.5 kHz

// ===============================
// CALLBACK MQTT
// ===============================
void callback(char* topic, byte* payload, unsigned int length) {
  Serial.println();
  Serial.println("========== PESAN MASUK ==========");
  Serial.print("Topic   : ");
  Serial.println(topic);

  String message;
  for (unsigned int i = 0; i < length; i++) {
    message += (char)payload[i];
  }
  message.trim();
  message.toLowerCase();
  message.replace("\"", "");
  message.replace("'", "");
  message.trim();

  Serial.print("Payload : [");
  Serial.print(message);
  Serial.println("]");

  if (message == "restock_on" || message == "restock" || message == "1" || message == "on") {
    restockMode = true;
    digitalWrite(ledPin, LOW);
    Serial.println(">> MODE RESTOCK AKTIF: LED OFF, publish dihentikan");
  }
  else if (message == "restock_off" || message == "normal" || message == "0" || message == "off") {
    restockMode = false;
    Serial.println(">> MODE NORMAL: LED & publish diaktifkan kembali");
  }
  else {
    Serial.println(">> Perintah tidak dikenal!");
  }
  Serial.println("=================================");
}

// ===============================
// FUNGSI BUZZER (State Machine)
// ===============================
void updateBuzzer(bool statusKosong, bool modeRestock) {
  // Mode restock = buzzer mati total
  if (modeRestock) {
    noTone(buzzerPin);
    buzzerState = BUZZER_IDLE;
    return;
  }

  // Status tersedia = buzzer diam
  if (!statusKosong) {
    if (buzzerState != BUZZER_IDLE) {
      noTone(buzzerPin);
      buzzerState = BUZZER_IDLE;
    }
    return;
  }

  // Status kosong = jalankan pattern beep-pause
  unsigned long now = millis();

  switch (buzzerState) {
    case BUZZER_IDLE:
      tone(buzzerPin, BUZZER_FREQ);
      buzzerTimer = now;
      buzzerState = BUZZER_BEEP;
      break;

    case BUZZER_BEEP:
      if (now - buzzerTimer >= BEEP_DURATION) {
        noTone(buzzerPin);
        buzzerTimer = now;
        buzzerState = BUZZER_PAUSE;
      }
      break;

    case BUZZER_PAUSE:
      if (now - buzzerTimer >= PAUSE_DURATION) {
        tone(buzzerPin, BUZZER_FREQ);
        buzzerTimer = now;
        buzzerState = BUZZER_BEEP;
      }
      break;
  }
}

// ===============================
// SETUP
// ===============================
void setup() {
  Serial.begin(115200);
  randomSeed(esp_random());

  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);
  pinMode(ledPin, OUTPUT);
  pinMode(buzzerPin, OUTPUT);

  // Inisialisasi OLED
  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println(F("SSD1306 allocation failed"));
    for (;;);
  }
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0);
  display.println("Smart Warehouse");
  display.println("Connecting WiFi...");
  display.display();

  // Koneksi WiFi
  Serial.println();
  Serial.print("Mencoba konek ke WiFi");
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println();
  Serial.println("WiFi Terhubung!");

  display.clearDisplay();
  display.setCursor(0, 0);
  display.println("WiFi Connected!");
  display.print("IP: ");
  display.println(WiFi.localIP());
  display.display();

  // Setup MQTT
  client.setServer(mqtt_server, mqtt_port);
  client.setCallback(callback);
  Serial.println("Setup MQTT selesai.");
}

// ===============================
// RECONNECT MQTT
// ===============================
void reconnect() {
  while (!client.connected()) {
    Serial.print("Mencoba konek ke MQTT Broker...");
    uint64_t chipid = ESP.getEfuseMac();
    String clientId = "ESP32_Wokwi_";
    clientId += String((uint32_t)chipid, HEX);
    clientId += "_";
    clientId += String(millis());

    if (client.connect(clientId.c_str())) {
      Serial.println("BERHASIL!");
      client.subscribe(mqtt_control_topic);
      Serial.print("Subscribe ke: ");
      Serial.println(mqtt_control_topic);
    } else {
      Serial.print("GAGAL, state=");
      Serial.println(client.state());
      delay(5000);
    }
  }
}

// ===============================
// LOOP UTAMA
// ===============================
void loop() {
  if (!client.connected()) {
    reconnect();
  }
  client.loop();

  // Update buzzer SETIAP LOOP (non-blocking)
  bool statusKosongNow = (distance >= 80) && !restockMode;
  updateBuzzer(statusKosongNow, restockMode);

  if (millis() - lastPublish >= PUBLISH_INTERVAL) {
    lastPublish = millis();

    // Baca sensor ultrasonik
    digitalWrite(trigPin, LOW);
    delayMicroseconds(2);
    digitalWrite(trigPin, HIGH);
    delayMicroseconds(10);
    digitalWrite(trigPin, LOW);
    duration = pulseIn(echoPin, HIGH);
    distance = duration * 0.034 / 2;

    String status = (distance >= 80) ? "kosong" : "tersedia";

    // Kontrol LED
    if (restockMode) {
      digitalWrite(ledPin, LOW);
    } else {
      digitalWrite(ledPin, (status == "kosong") ? HIGH : LOW);
    }

    // Update OLED
    display.clearDisplay();
    display.setCursor(0, 0);
    display.setTextSize(1);
    display.println("=== SMART WAREHOUSE ===");
    display.print("Jarak : "); display.print(distance); display.println(" cm");
    display.print("Status: "); display.println(status);
    display.print("Mode  : "); display.println(restockMode ? "RESTOCK" : "NORMAL");
    display.print("Buzzer: ");
    if (restockMode || status != "kosong") {
      display.println("OFF");
    } else {
      display.println(buzzerState == BUZZER_BEEP ? "BEEP!" : "...");
    }
    display.display();

    // Siapkan payload JSON
    JsonDocument doc;
    doc["rak_id"]       = "RAK-01";
    doc["status"]       = status;
    doc["jarak_cm"]     = distance;
    doc["restock_mode"] = restockMode;

    char jsonBuffer[256];
    serializeJson(doc, jsonBuffer);

    // Publish ke MQTT (kecuali mode restock)
    bool berhasil = false;
    if (!restockMode) {
      berhasil = client.publish(mqtt_topic, jsonBuffer);
    }

    // Serial Monitor log
    Serial.println("--------------------------------");
    Serial.print("Jarak        : "); Serial.print(distance); Serial.println(" cm");
    Serial.print("Status       : "); Serial.println(status);
    Serial.print("Restock Mode : "); Serial.println(restockMode ? "AKTIF" : "NONAKTIF");
    Serial.print("Buzzer State : ");
    switch (buzzerState) {
      case BUZZER_IDLE:  Serial.println("IDLE (diam)");   break;
      case BUZZER_BEEP:  Serial.println("BEEP (nyala)");  break;
      case BUZZER_PAUSE: Serial.println("PAUSE (jeda)");  break;
    }
    Serial.print("Payload      : "); Serial.println(jsonBuffer);
    if (restockMode) Serial.println("MQTT         : DILEWATI");
    else if (berhasil) Serial.println("MQTT         : TERKIRIM");
    else Serial.println("MQTT         : GAGAL");
    Serial.println("--------------------------------");
  }
}